
<?php include ("inc/meta.php");?>

<header class="header" id="header">
	<div class="container-fluid container-width">

		<nav class="navbar navbar-expand-lg">

			<div class="navbar-header col-md">
				<a class="navbar-brand" href="/" alt="Energy">
					<img src="assets/images/logo.png" alt="">
				</a>
			</div>

			<?php include ("template-parts/header/nav.php");?>

		</nav>
	</div>
</header>