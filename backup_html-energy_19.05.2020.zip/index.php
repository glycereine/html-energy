<?php include ("header.php");?>


<!-- <div class="content"> -->

	<?php include ("template-parts/front-page/hero.php");?>

	<?php include ("template-parts/front-page/home.php");?>

<!-- </div> -->
<!--///////////// Content -->

<?php include ("footer.php");?>