
<?php include ("header.php");?>

<div class="content">
    <div class="container-fluid">
        
        <h2>Хостинг / #{<?php print $PAGE_TITLE;?>}</h2>

        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. 
        Culpa dicta rerum alias vero velit unde corrupti aut, animi ipsum aliquid error saepe distinctio, praesentium sint laborum rem, nam deserunt quod.</p>
       
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. <br>
        Culpa dicta rerum alias vero velit unde corrupti aut, animi ipsum aliquid error saepe distinctio, praesentium sint laborum rem, nam deserunt quod.</p>

    </div>

</div>
<!--///////////// Content -->

<?php include ("footer.php");?>